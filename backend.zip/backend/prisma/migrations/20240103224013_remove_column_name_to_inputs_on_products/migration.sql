/*
  Warnings:

  - You are about to drop the column `name` on the `inputsOnProducts` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `inputsOnProducts` DROP COLUMN `name`;
