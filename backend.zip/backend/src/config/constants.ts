export enum ROLE {
  User = "USER",
  Admin = "ADMIN",
}
