export interface MeasurementUnitInput {
  name: string;
}

export interface MeasurementUnitContract {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
}
