export interface GroupInput {
  name: string;
}

export interface GroupContract {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
}